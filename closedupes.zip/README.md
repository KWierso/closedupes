# Close Dupes

## What it does

When a tab loads a url that's already open in another tab, that existing tab will be immediately closed.